//
//  ViewController.swift
//  Binary2Decimel
//
//  Created by Dua Almahyani on 09/10/2020.
//  Copyright © 2020 Dua Almahyani. All rights reserved.
//

import UIKit

extension String {
    func replace(_ with: String, at index: Int) -> String {
        var modifiedString = String()
        for (i, char) in self.enumerated() {
            modifiedString += String((i == index) ? with : String(char))
        }
        return modifiedString
    }
}

class ViewController: UIViewController {

    @IBOutlet weak var BinaryOutputLabel: UILabel!
    @IBOutlet weak var userNumberTextField: UITextField!
    
    
    var binary = "00000000"
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        

    }
    
    @IBAction func zero(_ sender: UISwitch) {
        if sender.isOn{
            binary = binary.replace("1", at: 7)
        }else{
            binary = binary.replace("0", at: 7)
        }
        BinaryOutputLabel.text = String(convertBinary2Decimal(binary))
        
        chanegBackground()
    }
    
    @IBAction func one(_ sender: UISwitch) {
        if sender.isOn{
            binary = binary.replace("1", at: 6)
        }else{
            binary = binary.replace("0", at: 6)
        }
        BinaryOutputLabel.text = String(convertBinary2Decimal(binary))
        
        chanegBackground()
    }
    
    @IBAction func two(_ sender: UISwitch) {
        if sender.isOn{
            binary = binary.replace("1", at: 5)
        }else{
            binary = binary.replace("0", at: 5)
        }
        BinaryOutputLabel.text = String(convertBinary2Decimal(binary))
        
        chanegBackground()
    }
    
    @IBAction func three(_ sender: UISwitch) {
        if sender.isOn{
            binary = binary.replace("1", at: 4)
        }else{
            binary = binary.replace("0", at: 4)
        }
        BinaryOutputLabel.text = String(convertBinary2Decimal(binary))
        
        chanegBackground()
    }
    
    @IBAction func four(_ sender: UISwitch) {
        if sender.isOn{
            binary = binary.replace("1", at: 3)
        }else{
            binary = binary.replace("0", at: 3)
        }
        BinaryOutputLabel.text = String(convertBinary2Decimal(binary))
        
        chanegBackground()
    }
    
    @IBAction func five(_ sender: UISwitch) {
        if sender.isOn{
            binary = binary.replace("1", at: 2)
        }else{
            binary = binary.replace("0", at: 2)
        }
        BinaryOutputLabel.text = String(convertBinary2Decimal(binary))
        
        chanegBackground()
    }
    
    @IBAction func six(_ sender: UISwitch) {
        if sender.isOn{
            binary = binary.replace("1", at: 1)
        }else{
            binary = binary.replace("0", at: 1)
        }
        BinaryOutputLabel.text = String(convertBinary2Decimal(binary))
        
        chanegBackground()
    }
    
    @IBAction func seven(_ sender: UISwitch) {
        if sender.isOn{
            binary = binary.replace("1", at: 0)
        }else{
            binary = binary.replace("0", at: 0)
        }
        BinaryOutputLabel.text = String(convertBinary2Decimal(binary))
        
        chanegBackground()
    }
    
    func convertBinary2Decimal(_ binary: String) -> Int {
        guard let number = Int(binary, radix: 2) else { return 0 }
        return number
    }
    
    func chanegBackground() {
        if BinaryOutputLabel.text == userNumberTextField.text {
            self.view.backgroundColor = .brown
        } else {
            self.view.backgroundColor = .white
        }
    }
    
    
}


